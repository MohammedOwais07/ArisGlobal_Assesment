package com.spring.Services;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.MappedSuperclass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.Mapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.spring.model.*;
import com.spring.repo.PassengerRepo;
import com.spring.repo.TicketRepo;
import com.spring.repo.TrainRepo;

@Component
public class TicketServices {
    @Autowired
	private PassengerRepo passengerRepo;
 
    @Autowired
    private TrainRepo trainRepo;
	
    private TicketRepo ticketRepo;
	
    public Passenger addPassenger( Passenger passenger) {
    	
    	return passengerRepo.save(passenger);
    }
	
  public Passenger getPassenger(int id) {
	   return  passengerRepo.findById(id).get();
  }
  public List<Passenger> getPassenger(){
	  return passengerRepo.findAll();
  }
  public Passenger updatePassenger(int id,Passenger passenger)
  {
	  passenger.setId(id);
	  return  passengerRepo.save(passenger);
  }
	 
  public Trains addTrainDetails(Trains train) {
	  return trainRepo.save(train);
  }
  
  public List<Trains> getTrainDetails(){
	  return trainRepo.findAll();
  } 
   
  /*
  public List<Trains> getFirstsc(Trains train){
	  
	  return     trainRepo.findByStartingsc(train.getSource());
  }*/
  /*
 
  public Trains generatePNR(Trains train) {
	  return ticketRepo.generatePNR(train.getSource());
  }*/
  
  
  public  Date  currentDate() {
 
 Date currentDate=new Date(System.currentTimeMillis());
 return currentDate;
  }
  @GeneratedValue(strategy = GenerationType.AUTO)
  int count =100;
  
  public String getPNR(String source,String destination) {
	  
	  Trains train = new Trains();
	  
       String sc=train.getSource().substring(1, 1);
	  String ds=train.getDestination().substring(1, 1);
	  String res=sc+ds;
	  
	  Date curDate=currentDate();
	  return res+"_"+curDate;
	  
	  
  }
  public int Calc_ticketprice(Integer age,Integer price) {
	  int ticket_price=0;
	  
	  if (age<=12) {
		   ticket_price=(price/100)*50;
		   
	  }
	  else if(age>=60) {
		  ticket_price=(price/100)*60;
	  }
	return ticket_price;
  }
  
  
}
  