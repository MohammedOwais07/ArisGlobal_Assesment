package com.spring.Services;

import java.io.IOException;

import com.spring.util.UserData;



public interface TrainService {

	String generatePNR(UserData users) throws IOException;
	
}
