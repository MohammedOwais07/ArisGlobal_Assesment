package com.spring.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;


import com.spring.model.Passenger;
import com.spring.model.Ticket;

@Repository
public interface PassengerRepo extends CrudRepository<Passenger,Integer>,JpaRepository<Passenger,Integer>{

	
	 @Override
		List<Passenger>  findAll();
}
