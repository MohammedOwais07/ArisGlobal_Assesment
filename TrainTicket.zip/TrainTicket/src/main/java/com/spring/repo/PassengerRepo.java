package com.spring.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;


import com.spring.model.Passenger;


public interface PassengerRepo extends JpaRepository<Passenger,Long>{

	
	
}