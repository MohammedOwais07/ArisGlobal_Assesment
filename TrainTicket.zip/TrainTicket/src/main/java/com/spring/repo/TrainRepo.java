package com.spring.repo;

import java.util.List;

import javax.persistence.MapKey;
import javax.persistence.Table;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.spring.model.Trains;


@Repository
public interface TrainRepo extends CrudRepository<Trains,Integer>,JpaRepository<Trains,Integer>{

	
	 @Override
		List<Trains> findAll();
	 /*
	 
	 @Query("select SUBSTRING(source,1,1) from trains")
	 List<Trains> findByStartingsc(String source);
	 */
}