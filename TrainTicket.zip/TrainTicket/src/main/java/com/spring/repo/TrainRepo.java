package com.spring.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.spring.model.Trains;

public interface TrainRepo extends JpaRepository<Trains,Long>{

	
	@Query("SELECT t FROM Trains t WHERE t.train_no = ?1")
	Trains findByTrainNumber(Long train_no);
}