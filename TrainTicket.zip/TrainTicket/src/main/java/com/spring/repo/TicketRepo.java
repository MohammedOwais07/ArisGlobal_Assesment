package com.spring.repo;

import java.util.List;

import javax.persistence.MappedSuperclass;
import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.Mapping;

import  com.spring.model.*;

import com.spring.model.Ticket;

@Repository
public interface TicketRepo extends CrudRepository<Ticket,Integer>,JpaRepository<Ticket,Integer>{

	
	 @Override
	List<Ticket>  findAll();
	
	 /*
	 String sc= "select SUBSTRING(source,1,1) from trains";
	 String ds="select SUBSTRING(destination,1,1) from trains";
	 @Transactional
	 @org.springframework.data.jpa.repository.Query(sc)
	 
	  public Trains generatePNR(@Param("source") String source) ;
	  */
}

