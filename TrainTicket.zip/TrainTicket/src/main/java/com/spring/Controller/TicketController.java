package com.spring.Controller;

import java.sql.Date;
import java.util.List;

import javax.persistence.MappedSuperclass;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.spring.Services.TicketServices;
import com.spring.model.Passenger;
import com.spring.model.Trains;

@RestController
@RequestMapping("/tickets")
public class TicketController {
	
@Autowired
private TicketServices ticketServices;

@PostMapping
public Passenger addPassenger(@RequestBody Passenger passenger)
{
	return ticketServices.addPassenger(passenger);
}

@GetMapping
public List<Passenger> getPassenger(){
	return  ticketServices.getPassenger();
}

@PostMapping("/addtrain")
public Trains addTrainDetails(@RequestBody Trains train) {
	return ticketServices.addTrainDetails(train);
}

@GetMapping("/TrainDetails")
public List<Trains> getTrainDetails(){
	return ticketServices.getTrainDetails();
}

@GetMapping("/date")
public   Date currentDate() {
	return ticketServices.currentDate();
}
@PostMapping("/ticketPrice")
public int calcTicketPrice(Integer age,Integer price) {
	
	return ticketServices.Calc_ticketprice(age, price);
}
@PostMapping("/getPNR")
public String getPNR( int id,@RequestBody Trains train ) {

	return ticketServices.getPNR(train.getSource(),train.getDestination());
}
/*
@GetMapping("/getPNR")
public List<Trains> getPNR(@RequestBody Trains train) {
	return ticketServices.getFirstsc(train);
}
*/

/*
@GetMapping(value="getPNR")

public Trains generatePNR(@RequestBody Trains train) {
	return ticketServices.generatePNR(train);
}*/

}
