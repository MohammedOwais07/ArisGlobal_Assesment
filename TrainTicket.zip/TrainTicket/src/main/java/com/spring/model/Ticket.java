package com.spring.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="ticket")
public class Ticket {
    
	@Id
	private int t_id;
	@Column
	private int counter;
	@Column
	private String pnr;
	@Column
	private Date travel_date;

	
	 public int getT_id() {
		return t_id;
	}

	public void setT_id(int t_id) {
		this.t_id = t_id;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public String getPnr() {
		return pnr;
	}

	public void setPnr(String pnr) {
		this.pnr = pnr;
	}

	public Date getTravel_date() {
		return travel_date;
	}

	public void setTravel_date(Date travel_date) {
		this.travel_date = travel_date;
	}

	public Trains getTrain() {
		return train;
	}

	public void setTrain(Trains train) {
		this.train = train;
	}

	public List<Passenger> getPassanger() {
		return passanger;
	}

	public void setPassanger(List<Passenger> passanger) {
		this.passanger = passanger;
	}
	

	public Ticket(int t_id, int counter, String pnr, Date travel_date, Trains train, List<Passenger> passanger) {
		super();
		this.t_id = t_id;
		this.counter = counter;
		this.pnr = pnr;
		this.travel_date = travel_date;
		this.train = train;
		this.passanger = passanger;
	}
	


	@Override
	public String toString() {
		return "Ticket [t_id=" + t_id + ", counter=" + counter + ", pnr=" + pnr + ", travel_date=" + travel_date
				+ ", train=" + train + ", passanger=" + passanger + "]";
	}



	@OneToOne(cascade = CascadeType.ALL)
	@JoinTable(name="ticket_train",joinColumns= {@JoinColumn(name="t_id")},inverseJoinColumns={@JoinColumn(name="train_no")})
 
	private Trains train;
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinTable(name="ticket_pasenger",joinColumns= {@JoinColumn(name="t_id")},inverseJoinColumns={@JoinColumn(name="id")})
	private List<Passenger> passanger;
	

	
	
}
